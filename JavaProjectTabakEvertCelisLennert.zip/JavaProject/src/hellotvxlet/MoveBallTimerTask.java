/*
Tabak Evert
Celis Lennert
2MTA
 */
package hellotvxlet;

import java.util.TimerTask;
import org.havi.ui.HScene;

/**
 *
 * @author student
 */
public class MoveBallTimerTask extends TimerTask {

    Ball ballTime;
    HScene sc;

//stellen nieuwe mc gelijk aan de meegegeven huidige waarde van het component mc_p
    public void MoveBallTimerTask(Ball ballTimeSend, HScene scene) {
        sc = scene;
        ballTime = ballTimeSend;
    }

    public void run() {
        //punt printen om timing te testen    
        System.out.println(".");


        if (ballTime.getY() < 500) {
            ballTime.move();
        } else {

            HelloTVXlet.verloren(sc);
        }
    }
}
