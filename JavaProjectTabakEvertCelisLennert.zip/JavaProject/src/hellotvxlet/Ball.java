/*
Tabak Evert
Celis Lennert
2MTA
 */
package hellotvxlet;

import java.awt.Color;
import java.awt.Graphics;
import org.havi.ui.HComponent;

/**
 *
 * @author student
 */
public class Ball extends HComponent {

    //bal tekenen
    final int RADIUS = 21;
    //variabelen
    int dx;           //x en y vanboven links
    int dy;
    private int velx;   //snelheid (aantal pixels per move call
    int vely;
    private int boundRight;  // max x en y waarden
    private int boundBottom;
    
    Block blok;
    Paddle paddle;

    //constructor
    public Ball(int x, int y, int velocityX, int velocityY, Block blok, Paddle paddle) {
        dx = x;
        dy = y;
        velx = velocityX;
        vely = velocityY;
        //   this.setBounds(x, y, x + radius, y + radius);
        this.setBounds(0, 0, 720, 576);
        setBounds(720, 576);
        this.blok = blok;
        this.paddle = paddle;
    }

    //etBounds
    public void setBounds(int width, int height) {
        boundRight = width - RADIUS;
        boundBottom = height - RADIUS;
    }

    // move
    public void move() {
        //snelheid bal
        blok.testCollision(this, dx, dy, RADIUS);
        paddle.testPaddleCollision(this, dx, dy, RADIUS);
        System.out.println("move =" + dx + "," + dy);
        dx += velx;
        dy += vely;

        //botsen

        if (dx < 0) {                  // als te ver naar links zet tegen rand en keer richting om

            dx = 0;
            velx = -velx;

        } else if (dx > boundRight) { // rechts

            dx = boundRight;
            velx = -velx;
        }

        if (dy < 0) {                 // top

            dy = 0;
            vely = -vely;

        } else if (dy > boundBottom) { //bottom

            dy = boundBottom;
            vely = -vely;
        }

        if (dy > 470) {
            System.out.println("verloren test ifloop");
        }

        repaint();
    }

    public void invertBallDirection() {

        velx = -velx;
        vely = -vely;

    }

    //teken
    public void paint(Graphics g) {

        g.setColor(Color.BLACK);
        g.fillOval(dx, dy, RADIUS, RADIUS);
    }

    //getDiameter, getX, getY
    public int getDiameter() {
        return RADIUS;
    }

    public int getX() {
        return dx;
    }

    public int getY() {
        return dy;
    }

    //getPosition
    public void setPosition(int x, int y) {
        dx = x;
        dy = y;
    }
}


