/*
Tabak Evert
Celis Lennert
2MTA
 */
 
//package met alle elementen van hellotvxlet, wat de overkoepelende klasse is voor alle tv decoders
package hellotvxlet;

//alle includes hier delen
import java.awt.Color;
import java.util.Timer;
import javax.tv.xlet.*;
import org.dvb.event.EventManager;
import org.dvb.event.UserEvent;
import org.dvb.event.UserEventListener;
import org.dvb.event.UserEventRepository;
import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;
import org.havi.ui.HStaticText;
import org.havi.ui.HVisible;

public class HelloTVXlet implements Xlet, UserEventListener {

    public HScene scene;
    Paddle pddl = new Paddle(0, 0, 720, 576);
    Block block = new Block(10, 10, 100, 50);
    Ball ball = new Ball(350, 325, 2, -2, block, pddl);

    public HelloTVXlet() {
    }

//hier maken we de initialisatiefuctie aan waarin we onze scene gaan vullen met elementen. We moeten deze eerst tekenen.
    public void initXlet(XletContext context) {

        scene = HSceneFactory.getInstance().getDefaultHScene();

        UserEventRepository rep = new UserEventRepository("naam");

        rep.addAllArrowKeys();
        EventManager manager = EventManager.getInstance();
        manager.addUserEventListener(this, rep);

        //paddle
        scene.add(pddl);

        //ball
        scene.add(ball);
        scene.popToFront(ball);

        //blocks
        scene.add(block);
        scene.popToFront(block);

        scene.repaint();
        // scene.validate checkt of alle elementen passen en kloppen dit dat
        scene.validate();
        //zet de scene op zichtbaar, heel belangrijk ni vergeten grts anders heb je geen beeld haha domme evert
        scene.setVisible(true);

        Timer t = new Timer();
        MoveBallTimerTask ttm = new MoveBallTimerTask();
        ttm.MoveBallTimerTask(ball, scene);
        t.scheduleAtFixedRate(ttm, 0, 15);
    }

    //negeer dees allemaal maar tot volgende commentaar da is stnadaard stuff 
    public void startXlet() {
    }

    public void pauseXlet() {
    }

    public void destroyXlet(boolean unconditional) {
    }

    public static void verloren(HScene sc) {

        sc.removeAll();
        HStaticText lostBox = new HStaticText("Verloren", 200, 250, 280, 50);
        lostBox.setBackgroundMode(HVisible.BACKGROUND_FILL);
        lostBox.setBackground(Color.RED);
        sc.add(lostBox);
        sc.repaint();

    }

    public void userEventReceived(UserEvent e) {
        if (e.getCode() == 37) {
            //verschuiven we de x of y coordinaat van het ruimteschip in de richting van dat pijltje

            if (pddl.x > 0) {
                pddl.x -= 10;
            }
            pddl.repaint();
        }

        if (e.getCode() == 39) {
            if (pddl.x < 720 - pddl.paddle.getWidth(pddl)) {
                pddl.x += 10;
            }
            pddl.repaint();
        }
    }
}