/*
Tabak Evert
Celis Lennert
2MTA
 */
package hellotvxlet;

import java.awt.Color;
import java.awt.Graphics;
import org.havi.ui.HComponent;

/**
 *
 * @author student
 */
public class Block extends HComponent {

    int x, y, widthBlock, heightBlock;
    boolean[][] blok = new boolean[10][5];
    int afstandLang = 73;
    int blockLang = 63;
    int afstandhoog = 40;
    int blockHoog = 30;

    //constructor
    public Block(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        widthBlock = width;
        heightBlock = height;

        this.setBounds(0, 0, 720, 576);
        
        for (int bx = 0; bx < 10; bx++) {
            for (int by = 0; by < 5; by++) {
                blok[bx][by] = true;
            }
        }
    }

    public void testCollision(Ball b, int x, int y, int rad) {
        for (int bx = 0; bx < 10; bx++) {
            for (int by = 0; by < 5; by++) {
                if (blok[bx][by]) {

                    int blokx = bx * afstandLang;
                    int bloky = by * afstandhoog;
                    if (x + b.RADIUS >= blokx) {
                        if (y <= bloky + blockHoog) {
                            if (x <= blokx + blockLang) {
                                blok[bx][by] = false;
                                b.invertBallDirection();
                                return;
                            }
                        }
                    }
                }
            }
        }
    }



    //teken
    public void paint(Graphics g) {
        for (int bx = 0; bx < 10; bx++) {
            for (int by = 0; by < 5; by++) {
                if (blok[bx][by]) {
                    if ((bx + by) % 3 == 2) {
                        g.setColor(Color.BLUE);
                    }
                    if ((bx + by) % 3 == 0) {
                        g.setColor(Color.GREEN);
                    }
                    if ((bx + by) % 3 == 1) {
                        g.setColor(Color.RED);
                    }
                    g.fillRect(bx * afstandLang, by * afstandhoog, blockLang, blockHoog);
                }
            }
        }
    }

    //getPosition
    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }
}


