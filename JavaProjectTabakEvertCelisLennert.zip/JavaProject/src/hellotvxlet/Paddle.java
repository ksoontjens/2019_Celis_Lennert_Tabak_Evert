/*
Tabak Evert
Celis Lennert
2MTA
 */
package hellotvxlet;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import org.havi.ui.HComponent;

/**
 *
 * @author student
 */
public class Paddle extends HComponent {

    //we maken een nieuw component dat een aantal png's gaat bevatten
    //gewoon een aantal lokale variabelen 
    int x = 300;
    int y = 480;
    int ay = 0;
    // een image is gewoon hey ik wil een foto in mijn programma zetten hoe doe ik dat ah image 
    Image wallpaper;
    Image paddle;

    //C:\Program Files\TechnoTrend\TT-MHP-Browser\fileio\DSMCC\0.0.3
    //constructor van MijnComponent, elke keer als je een MijnComponent aanmaakt
    //moet je een x en y coordinaat meegeven voor hoogte en breedte en een x2 en y2 voor hun postitie op je scene
    public Paddle(int x, int y, int x2, int y2) {

        //Op dit component gaan we met setbounds de eigenschappen hierboven instellen want tot nu toe waren dit gewoon getallen
        //die je met je object hebt meegegeven bij de creatie
        this.setBounds(x, y, x2, y2);

        //hier zetten we bijhorende beelden in de variabelen die we gaan toevoegen aan de scene
        wallpaper = this.getToolkit().getImage("./wallpaper.png");
        paddle = this.getToolkit().getImage("paddle.png");

        //een mediatracker houdt de positie bij van een image
        //als ge die wilt doen bewegen moet u programma kunnen onthouden waar die is en da doe een mediatracker
        MediaTracker mt = new MediaTracker(this);
        //voeg de img toe aan de mediatracker
        mt.addImage(paddle, 1);


    }

    //paint methode gaan we gebruiken in hellotvxlet om onze images te tekenen.
    //die staat hier omdat die gebruikt moet worden op objecten van het type MijnComponent
    public void paint(Graphics g) {

        /*
        g.drawImage tekent object
        sterren, 0, ay, this
        naam	x	y	hallojaditobjectennidegelijkaardigefilemetzelfdenaam
         */
        //ay hebben we vanboven op 0 gezet om makkelijk te kunnen werken met een veranderende y coordinaat.
        //we laten een sterrenkaat schuiven op onze scene, en een 2e sterrenkaart er onder om deze aan te vullen
        g.drawImage(wallpaper, 0, ay, this);
        g.drawImage(paddle, x, y, this);
        System.out.println(y);

    }

    public void testPaddleCollision(Ball b, int bx, int by, int rad) {

        if (bx + b.RADIUS >= x) {
            if (by + b.RADIUS >= y) {
                if (by + b.RADIUS <= y + paddle.getHeight(this)) {
                    if (bx <= x + paddle.getWidth(this)) {
                        b.vely = -b.vely;
                        //            b.invertBallDirection();
                        return;
                    }
                }
            }
        }

    //  b.invertBallDirection();
    }
}
       
